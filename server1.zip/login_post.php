<?
 $id = $_POST["id"];
 $pw = $_POST["pw"];
 $connect = mysql_connect("localhost","shuphin","shuphin1");
 mysql_select_db("shuphin");
 $query  = "select * from l_db where email='$id'";
 $result = mysql_query($query,$connect);
 $row =  mysql_fetch_array($result);

 if(count($row) == 1) {
	 echo "idx";
 }
 else if($row['pw'] != $pw) {
	 echo "pwx";
 }else {
     echo "success";
 }
 mysql_close($connect);
?>
